(function() {
    // Initialize Swiper slider
    const swiper = new Swiper('.tms-team-member-slider', {
        slidesPerView: 1,
        spaceBetween: 10,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        loop: true, // Enable endless loop
        slidesPerGroup: 2, // Move 2 slides on navigation
        breakpoints: {
            640: {
                slidesPerView: 2,
                spaceBetween: 20,
            },
            768: {
                slidesPerView: 2,
                spaceBetween: 30,
            },
            1024: {
                slidesPerView: 3, // Show 3 slides on desktop
                spaceBetween: 40,
            },
        },
    });

    console.log("Swiper initialized successfully:", swiper);
})();